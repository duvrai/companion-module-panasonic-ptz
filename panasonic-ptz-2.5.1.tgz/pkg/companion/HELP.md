Panasonic PTZ Cameras

## This module supports the following Panasonic PTZ cameras.

**AW-HE2, AW-HE50, AW-HE60, AW-HE120, AW-HE130, AW-HR140, AW-UE4, AW-SFU01, AK-UB300, <br/>AW-HE40 series, AW-HE42 series, AW-UE70 series, AW-UE150 series**

**HE40 series**

- AW-HE35, AW-HE38, AW-HE40, AW-HE48, AW-HE58, AW,HE65, AW-HE70
- AW-HN38, AW-HN40, AW-HN65, AW-HN70
- AW HEF5

**HE42 series**

- AW-HE42, AW-HE68, AW-HE75

**UE70 series**

- AW-UE63, AW-UE65, AW-UE70
- AW-UN70

**UE150 series**

- AW-UE100, AW-UE150, AW-UE155
- AW-UN145

**Disclaimer, not all models supports all actions, variables and feedbacks. But it should be auto sorted so that you can only use actions, feedbacks, variables and presets that works with your model**

## When using more than on PTZ

**When Configuring** more than one instance, please make sure you have **"AUTO TCP"** enabled or change the **TCP** port accordingly, this is a port used in companion, and you will not find a setting for it on the cameras. The TCP port **NEEDS** to be unique for each PTZ instance you add. It's strongly recomended to leave **"Auto TCP"** turned on.

## Actions

The actions are separated into the following categories.
It's recommended to use the presets as much as possible as there is a lot of actions.

**Pan/Tilt**

- Up, Down, Left, Right, UpLeft, UpRight, DownLeft, DownRight
- Set Pan/Tilt Speed
- Set Pan and Tilt speeds independently
- Pan/Tilt Speed Up
- Pan Speed Up
- Tilt Speed Up
- Pan/Tilt Speed Down
- Pan Speed Down
- Tilt Speed Down
- Pan/Tilt Home
- Adjust pan/tilt velocity on speed change

**Lens**

- Zoom In
- Zoom Out
- Set Zoom Speed
- Zoom Speed Up
- Zoom Speed Down
- Adjust zoom quickness on speed change
- Focus Far, Focus Near
- Set Focus Speed
- Focus Speed Up
- Focus Speed Down
- Adjust focus quickness on speed change
- Focus Mode (Auto/Manual)
- One Touch Auto Focus (OTAF)

**Exposure**

- Set Iris
- Iris Open
- Iris Close
- Iris Mode (Auto/Manual)
- Set Gain
- Gain Up
- Gain Down
- Set Shutter
- Shutter Up
- Shutter Down
- Set Pedestal
- Pedestal Up
- Pedestal Down
- Set ND Filter
- ND Filter Up
- ND Filter Down

**System**

- Power Off
- Power On
- Installation position Desktop and Hanging
- Tally Off
- Tally On
- SD Card Recording Start/Stop

**Save presets**

- Save Preset 1-100

**Recall Presets**

- Recall Preset 1-100
- Set Preset Playback Speed
- Set Preset Playback Time (AW-UE150)
- Set Preset Playback Mode (AW-UE150)

## Variables

A list of all the available Variables in this module sorted into the following categories. For their correct naming, refer to the list under "Edit" "Instance".

**System**

- PTZ Series
- PTZ Model
- PTZ Name
- Firmware Version
- PTZ Error Codes
- Power ON/OFF
- Install Position
- Tally State

**Lens**

- Auto Focus Mode
- Pan/Tilt, Zoom and Focus Speed

**Exposure**

- Auto Iris Mode

## Feedbacks

A list of all the available Feedbacks in this module sorted into the following categories.

**System**

- Power ON/OFF
- Tally State
- Install Position

**Lens**

- Auto Focus Mode

**Exposure**

- Auto Iris Mode

**Preset**

- Stored (select preset number; indicate when stored or not stored)

## Variables (Preset)

- Stored Preset Numbers (comma-separated list of stored preset slots, e.g. `1, 2, 3`)

Current support is based on "HD/4K Integrated Camera Interface Specifications" version 1.12 from Apr. 27, 2020.

For additional actions, please raise a feature request on [GitHub](https://github.com/bitfocus/companion-module-panasonic-ptz/).
